# -*- coding: utf-8 -*-
"""
Created on Jun 2020

@author: Carollo Andrea - Tomasi Matteo
"""

import numpy as np
import os
from math import sqrt

np.set_printoptions(precision=3, linewidth=200, suppress=True)
LINE_WIDTH = 60

T = 2                           # OCP horizon
dt = 0.02                       # OCP time step
SHOW_THE_FIRST_MOVEMENT = False
SHOW_Iter_1             = False
SHOW_Iter_2             = True
integration_scheme      = 'RK-4'
use_finite_difference   = False
sanity_check            = False


RUN_FIXED_POINT = False     # enalble running fixed point
RUN_TRAJ_JS     = False     # enalble running trajectory on joint space

# FINAL COSTS FLAGs & WEIGHTs
FIN_FIXED_POINT = True      # cost function weight for final position - task or joint space -
weight_pos      = 1e-1

FIN_VEL         = True
weight_vel      = 1e-1      # cost function weight for final velocity

# RUNNING COSTS FLAGs & WEIGHTs
RUN_QUAD        = False     # enalble running quadratic cost
weight_u        = 1e-7      # cost function weight for control

RUN_JOINT_VEL   = False     # enalble running joint velocity
weight_vel_r    = 1e-12     # cost function weight for velocity during the trajectory

RUN_TRAJ_TS     = True      # enalble running trajectory on task space
weight_traj     = 6         # cost function weight for follow a trajectory during the time interval [0 T]

RUN_POSTURAL    = False     # enalble running postural task
weight_post     = 1e-12     # cost function weight for the postural task

RUN_ORTH_EE     = True      # enalble running orthogonality with the floor
weight_orth     = 5e-3      # cost function weigth to keep the end effector orthogonal to the ground



# SYSTEM PARAMETERS
system = 'ur'
nq      = 6
q0      = np.array([ -0.3 , -0.9,  2.1 , -1.2-0.5*np.pi,  1.5*np.pi ,  0. ])       # initial configuration
p_des   = np.array([ 0.4 , 0.4, -0.05 ])


# COST WEIGHTS FOR THE FIRST OCP - WITHOUT CONTACTS
# Final costs weights
weight_vel_1    = 1e-1      # cost function weight for final velocity
# Running cost weights
weight_traj_1   = 6e+0      # cost function weight for follow a trajectory during the time interval [0 T]


# COST WEIGHTS FOR THE SECOND OCP - WITH CONTACTS
# Final costs weights
# ...
# Running cost weights
# ...


# contact points
frame_name = 'tool0'    # name of the frame to control (end-effector)
#frame_name = 'ee_link'   # name of the frame to control (end-effector)
contact_frames = [frame_name]

# data of the contact surface floor
contact_surface_name = 'floor'
contact_surface_pos = np.array([0., 0., 0.])
contact_normal = np.array([0., 0., 1.])

K = 50*np.diagflat([1., 1., 1.])
B = 5*np.diagflat([1., 1., 1.])
mu = 0.3


# REACTIVE CONTROL
ndt_rc = 10
dt_RC  = dt/ndt_rc       # RC time step

kp   = 10                # proportional gain of end effector task - force control
kp_j = 500               # proportional gain of joint task
kd_j = 2*sqrt(kp_j)      # derivative gain of joint task

# data of the contact surface floor - Reactive control
K_RC = 3e3*np.diagflat([1., 1., 1.])
B_RC = 5e1*np.diagflat([1., 1., 1.])



# SIMULATION PARAMETERS
simulate_coulomb_friction = 1    # flag specifying whether coulomb friction is simulated
simulation_type = 'timestepping' # either 'timestepping' or 'euler'
tau_coulomb_max = 10*np.ones(nq)   # expressed as percentage of torque max

randomize_robot_model = 1
model_variation = 30.0

use_viewer = True
simulate_real_time = 1        # flag specifying whether simulation should be real time or as fast as possible
show_floor = True
PRINT_T = 1                   # print some info every PRINT_T seconds
DISPLAY_T = 0.02              # update robot configuration in viwewer every DISPLAY_T seconds
CAMERA_TRANSFORM = [1.0568891763687134, 0.7100808024406433, 0.39807042479515076, 
                    0.2770655155181885, 0.5401807427406311, 0.6969326734542847, 0.3817386031150818]
